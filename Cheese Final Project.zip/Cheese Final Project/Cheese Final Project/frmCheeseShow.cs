using static Cheese_Final_Project.Snacks;
using System.Windows.Forms;
using System.Xml.Linq;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Cheese_Final_Project
{
    public partial class frmCheeseShow : Form
    {
        public frmCheeseShow()
        {
            InitializeComponent();
        }

        private void iAdd_Click_1(object sender, EventArgs e)
        {
            

            Snack newSnack = new Snack(iName.Text, iCategory.Text, (int)iRating.Value, iIngredients.Text, iFavorite.Checked, iSubmittedBy.Text);

            listBox.Items.Add(newSnack.Name + " " + newSnack.Category);

            listBox.Items.Add(newSnack.Display());

            // insert the recipe into the database
            DatabaseHelp.InsertSnack(newSnack.Name, newSnack.Category, newSnack.Rating, newSnack.Ingredients, newSnack.IsFavorite, Convert.ToInt32(newSnack.SubmittedBy));
            LoadSnacks();

            Thread.Sleep(2000);

            // update
            DatabaseHelp.UpdateSnack(4, newSnack.Name + " Super Duper", newSnack.Category, newSnack.Rating, newSnack.Ingredients, newSnack.IsFavorite, Convert.ToInt32(newSnack.SubmittedBy));
            LoadSnacks();
        }

        private void LoadSnacks()
        {
            dgvView.DataSource = DatabaseHelp.GetAllSnacks();
        }

        private void frmCheeseShow_Load(object sender, EventArgs e)
        {
            InitMenu();
            LoadSnacks();
        }

        private void InitMenu()
        {
            
            ToolStripMenuItem mnuItemRecipeShow = new ToolStripMenuItem("Cheese Show");

            
            mnuItemRecipeShow.Click += (s, e) =>
            {
                frmCheeseShow frmRS = new frmCheeseShow();
                frmRS.Show();

                this.Hide();
            };

            mnuMain.Items.Add(mnuItemRecipeShow);
        }

        private void mnuMain_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void iName_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}
