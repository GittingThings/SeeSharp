﻿namespace Cheese_Final_Project
{
    public class Snacks
    {
        public class Snack
        {
            private int cheeseRating;

            // Name property
            public string Name { get; set; }
            // Category property
            public string Category { get; set; }

            //Rating
            public int Rating
            {
                get { return cheeseRating; }
                set
                {
                    
                    if (value > 0)
                    {
                        cheeseRating = value;
                    }
                    
                    else
                    {
                        cheeseRating = 1;
                    }
                }
            }

            // Ingredients
            public string Ingredients { get; set; }

            // Favorite
            public bool IsFavorite { get; set; }

            // Submitted By
            public string SubmittedBy { get; set; }

            // Constructor
            public Snack(string name, string category, int rating, string ingredients, bool isFavorite, string submittedBy)
            {
                Name = name;
                Category = category;
                Rating = rating;
                Ingredients = ingredients;
                IsFavorite = isFavorite;
                SubmittedBy = submittedBy;
            }

            public virtual string Display()
            {
                return Name + " (" + Category + ")";
            }

            public virtual string Display(int num)
            {
                if (num == 2)
                {
                    return Name + " (" + Category + ")";
                }
                else
                {
                    return Name;
                }
            }
        }
    }
}
