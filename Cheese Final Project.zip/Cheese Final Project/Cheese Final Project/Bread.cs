﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cheese_Final_Project
{
    public class Bread : Snacks.Snack
    {
        public string CrustType { get; set; }

        public Bread(string name, string category, int rating, string ingredients, bool isFavorite, string submittedBy, string crustType)
            : base(name, category, rating, ingredients, isFavorite, submittedBy)
        {
            CrustType = crustType;
        }

    }
}

