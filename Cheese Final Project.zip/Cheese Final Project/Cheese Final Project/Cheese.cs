﻿using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cheese_Final_Project
{
    

        public class Cheese : Snacks.Snack
        {
            public string Texture { get; set; }

            public Cheese(string name, string category, int rating, string ingredients, bool isFavorite, string submittedBy, string texture)
                : base(name, category, rating, ingredients, isFavorite, submittedBy)
            {
                Texture = texture;
            }

        }
}
