﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;

namespace Cheese_Final_Project
{
    public static class DatabaseHelp
    {
        private static readonly string strConnSnack = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFileName=|DataDirectory|\Food.mdf;Integrated Security=True;Connect Timeout=30";

        public static DataTable GetAllSnacks()
        {
            // return rows
            string strQuery = "SELECT * FROM tblSnack";

            // open a connection to the database
            using (SqlConnection connection = new SqlConnection(strConnSnack))
            {
                //seting up commands
                using (SqlCommand cmd = new SqlCommand())
                {
                    connection.Open();

                    //dta adapter
                    SqlDataAdapter adapter = new SqlDataAdapter(strQuery, strConnSnack);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    // return table
                    return table;

                    connection.Close();
                }
            }
        }

        public static void InsertSnack(string strName, string strCategory, int intRating, string strIngredients, bool bIsFav, int intSubmittedBy)
        {
            //database record
            string strQuery = @"INSERT INTO tblSnack
                               (snack_name, rating, ingredients, is_Favorite, fk_user)
                               VALUES (@snack_name, @rating, @ingredients, @is_Favorite, @fk_user)";

            // open a connection to the database
            using (SqlConnection connection = new SqlConnection(strConnSnack))
            using (SqlCommand cmd = new SqlCommand(strQuery, connection))
            {
                // commands for variables
               
                cmd.Parameters.AddWithValue("@snack_name", strName);
                cmd.Parameters.AddWithValue("@rating", intRating);
                cmd.Parameters.AddWithValue("@ingredients", strIngredients);
                cmd.Parameters.AddWithValue("@is_favorite", bIsFav);
                cmd.Parameters.AddWithValue("@fk_user", intSubmittedBy);

                //open connection
                connection.Open();

                // add record
                cmd.ExecuteNonQuery();

                connection.Close();
            }
        }

        public static void UpdateSnack(int intSnackId, string strName, string strCategory, int intRating, string strIngredients, bool bIsFav, int intSubmittedBy)
        {
            // Update Record
            string strQuery = @"UPDATE tblSnack SET
                                snack_name = @snack_name, 
                                rating = @rating, 
                                ingredients = @ingredients, 
                                is_favorite = @is_favorite, 
                                fk_user = @fk_user
                                WHERE pk_Snack = @pk_Snack";

            // database conection
            using (SqlConnection connection = new SqlConnection(strConnSnack))
            using (SqlCommand cmd = new SqlCommand(strQuery, connection))
            {
                // commands for adding the parameters to the insert query
                cmd.Parameters.AddWithValue("@Snack_name", strName);
                cmd.Parameters.AddWithValue("@Rating", intRating);
                cmd.Parameters.AddWithValue("@ingredients", strIngredients);
                cmd.Parameters.AddWithValue("@is_favorite", bIsFav);
                cmd.Parameters.AddWithValue("@fk_user", intSubmittedBy);
                cmd.Parameters.AddWithValue("@pk_snack", intSnackId);

                // open connection
                connection.Open();

                // add record
                cmd.ExecuteNonQuery();

                connection.Close();
            }
        }
    }
}
