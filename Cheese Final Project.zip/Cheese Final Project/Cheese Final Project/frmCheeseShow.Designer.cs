﻿namespace Cheese_Final_Project
{
    partial class frmCheeseShow
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            listBox = new ListBox();
            iName = new TextBox();
            iFavorite = new CheckBox();
            iCategory = new ComboBox();
            iAdd = new Button();
            label2 = new Label();
            iRating = new NumericUpDown();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            dgvView = new DataGridView();
            iIngredients = new TextBox();
            iSpecialty = new TextBox();
            mnuMain = new MenuStrip();
            iSubmittedBy = new TextBox();
            ((System.ComponentModel.ISupportInitialize)iRating).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvView).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(13, 28);
            label1.Name = "label1";
            label1.Size = new Size(55, 15);
            label1.TabIndex = 0;
            label1.Text = "Category";
            // 
            // listBox
            // 
            listBox.FormattingEnabled = true;
            listBox.ItemHeight = 15;
            listBox.Location = new Point(340, 24);
            listBox.Name = "listBox";
            listBox.Size = new Size(448, 169);
            listBox.TabIndex = 1;
            // 
            // iName
            // 
            iName.Location = new Point(73, 54);
            iName.Name = "iName";
            iName.Size = new Size(121, 23);
            iName.TabIndex = 2;
            // 
            // iFavorite
            // 
            iFavorite.AutoSize = true;
            iFavorite.Location = new Point(111, 170);
            iFavorite.Name = "iFavorite";
            iFavorite.Size = new Size(68, 19);
            iFavorite.TabIndex = 3;
            iFavorite.Text = "Favorite";
            iFavorite.UseVisualStyleBackColor = true;
            // 
            // iCategory
            // 
            iCategory.FormattingEnabled = true;
            iCategory.Items.AddRange(new object[] { "Cheese Snack", "Bread Snack", "Regular Drink", "Carbonated Dink" });
            iCategory.Location = new Point(72, 25);
            iCategory.Name = "iCategory";
            iCategory.Size = new Size(121, 23);
            iCategory.TabIndex = 4;
            // 
            // iAdd
            // 
            iAdd.Location = new Point(12, 170);
            iAdd.Name = "iAdd";
            iAdd.Size = new Size(75, 23);
            iAdd.TabIndex = 5;
            iAdd.Text = "Add";
            iAdd.UseVisualStyleBackColor = true;
            iAdd.Click += iAdd_Click_1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(1, 115);
            label2.Name = "label2";
            label2.Size = new Size(66, 15);
            label2.TabIndex = 6;
            label2.Text = "Ingredients";
            // 
            // iRating
            // 
            iRating.Location = new Point(73, 83);
            iRating.Name = "iRating";
            iRating.Size = new Size(120, 23);
            iRating.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(26, 85);
            label3.Name = "label3";
            label3.Size = new Size(41, 15);
            label3.TabIndex = 8;
            label3.Text = "Rating";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(28, 57);
            label4.Name = "label4";
            label4.Size = new Size(39, 15);
            label4.TabIndex = 9;
            label4.Text = "Name";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(13, 144);
            label5.Name = "label5";
            label5.Size = new Size(54, 15);
            label5.TabIndex = 10;
            label5.Text = "Specialty";
            // 
            // dgvView
            // 
            dgvView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvView.Location = new Point(12, 199);
            dgvView.Name = "dgvView";
            dgvView.Size = new Size(776, 247);
            dgvView.TabIndex = 11;
            // 
            // iIngredients
            // 
            iIngredients.Location = new Point(73, 112);
            iIngredients.Name = "iIngredients";
            iIngredients.Size = new Size(121, 23);
            iIngredients.TabIndex = 12;
            // 
            // iSpecialty
            // 
            iSpecialty.Location = new Point(73, 141);
            iSpecialty.Name = "iSpecialty";
            iSpecialty.Size = new Size(121, 23);
            iSpecialty.TabIndex = 13;
            // 
            // mnuMain
            // 
            mnuMain.Location = new Point(0, 0);
            mnuMain.Name = "mnuMain";
            mnuMain.Size = new Size(800, 24);
            mnuMain.TabIndex = 14;
            mnuMain.Text = "menuStrip1";
            // 
            // iSubmittedBy
            // 
            iSubmittedBy.Location = new Point(234, 166);
            iSubmittedBy.Name = "iSubmittedBy";
            iSubmittedBy.Size = new Size(100, 23);
            iSubmittedBy.TabIndex = 15;
            // 
            // frmCheeseShow
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(iSubmittedBy);
            Controls.Add(iSpecialty);
            Controls.Add(iIngredients);
            Controls.Add(dgvView);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(iRating);
            Controls.Add(label2);
            Controls.Add(iAdd);
            Controls.Add(iCategory);
            Controls.Add(iFavorite);
            Controls.Add(iName);
            Controls.Add(listBox);
            Controls.Add(label1);
            Controls.Add(mnuMain);
            MainMenuStrip = mnuMain;
            Name = "frmCheeseShow";
            Text = "Form1";
            Load += frmCheeseShow_Load;
            ((System.ComponentModel.ISupportInitialize)iRating).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ListBox listBox;
        private TextBox iName;
        private CheckBox iFavorite;
        private ComboBox iCategory;
        private Button iAdd;
        private Label label2;
        private NumericUpDown iRating;
        private Label label3;
        private Label label4;
        private Label label5;
        private DataGridView dgvView;
        private TextBox iIngredients;
        private TextBox iSpecialty;
        private MenuStrip mnuMain;
        private TextBox iSubmittedBy;
    }
}
