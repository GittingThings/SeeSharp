﻿namespace Cheese_Final_Project
{
    public class CarbonatedDrink : Drink
    {
        public int BubbleLevel { get; set; }

        public CarbonatedDrink(string name, string type, int rating, string ingredients, bool isCarbonated, string submittedBy, int bubbleLevel)
            : base(name, type, rating, ingredients, isCarbonated, submittedBy)
        {
            BubbleLevel = bubbleLevel;
        }

       
    }
}
