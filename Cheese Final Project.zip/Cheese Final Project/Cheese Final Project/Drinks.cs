﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cheese_Final_Project
{
    public class Drink
    {
        private int drinkRating;

        // Name property
        public string Name { get; set; }

        // Type property
        public string Type { get; set; }

        // Rating property
        public int Rating
        {
            get { return drinkRating; }
            set
            {
                if (value > 0)
                    drinkRating = value;
                else
                    drinkRating = 1;
            }
        }

        // Ingredients
        public string Ingredients { get; set; }

        // IsCarbonated
        public bool IsCarbonated { get; set; }

        // SubmittedBy
        public string SubmittedBy { get; set; }

        // Constructor
        public Drink(string name, string type, int rating, string ingredients, bool isCarbonated, string submittedBy)
        {
            Name = name;
            Type = type;
            Rating = rating;
            Ingredients = ingredients;
            IsCarbonated = isCarbonated;
            SubmittedBy = submittedBy;
        }

        public virtual string Display()
        {
            return Name + " (" + Type + ")";
        }

        public virtual string Display(int num)
        {
            if (num == 2)
                return Name + " (" + Type + ")";
            else
                return Name;
        }
    }
}
