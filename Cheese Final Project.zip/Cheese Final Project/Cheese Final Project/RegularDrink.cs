﻿namespace Cheese_Final_Project
{
    public class RegularDrink : Drink
    {
        public string Flavor { get; set; }

        public RegularDrink(string name, string type, int rating, string ingredients, bool isCarbonated, string submittedBy, string flavor)
            : base(name, type, rating, ingredients, isCarbonated, submittedBy)
        {
            Flavor = flavor;
        }

    }
}
