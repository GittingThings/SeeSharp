﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace D_D_Character_Maker
{
    public partial class frmShowChar : Form
    {
        public frmShowChar()
        {
            InitializeComponent();
        }

        private void dgvCharacters_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void frmShowChar_Load(object sender, EventArgs e)
        {
            // Connection string to database in project
            string strConnString = @"Data Source=(LocalDb)\MSSQLLocalDB;AttachDbFilename=C:\Users\LiamF\source\repos\D&D Character Maker\D&D Character Maker\CharInfo.mdf;Integrated Security=True;Connect Timeout=30;";


            // Query 
            string strQuery = "SELECT * FROM tblCharacter";

            // Setting up connection
            using (SqlConnection connection = new SqlConnection(strConnString))
            {
                connection.Open();

                //Creating data adapter
                SqlDataAdapter adapter = new SqlDataAdapter(strQuery, connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dgvCharacters.DataSource = table;
            }
        }
    }
}