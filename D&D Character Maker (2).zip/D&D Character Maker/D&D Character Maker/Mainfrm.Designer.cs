﻿namespace D_D_Character_Maker
{
    partial class Mainfrm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mainfrm));
            PC1 = new PictureBox();
            PC2 = new PictureBox();
            LBMain = new ListBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            lbl1 = new Label();
            textBox2 = new TextBox();
            CISpec1 = new TextBox();
            WpnName2 = new TextBox();
            CIPlayerName = new TextBox();
            WpnName1 = new TextBox();
            WpnName3 = new TextBox();
            CILevel = new NumericUpDown();
            CIHealth = new NumericUpDown();
            numericUpDown3 = new NumericUpDown();
            numericUpDown4 = new NumericUpDown();
            numericUpDown5 = new NumericUpDown();
            numericUpDown6 = new NumericUpDown();
            numericUpDown7 = new NumericUpDown();
            numericUpDown8 = new NumericUpDown();
            CIName = new TextBox();
            label9 = new Label();
            CISpec = new ComboBox();
            btnCreate = new Button();
            label10 = new Label();
            CIRace = new ComboBox();
            CIAlignment = new ComboBox();
            CIBackground = new ComboBox();
            SCCastAbility = new ComboBox();
            lbl2 = new Label();
            checkedListBox1 = new CheckedListBox();
            CISpec2 = new NumericUpDown();
            label12 = new Label();
            ((System.ComponentModel.ISupportInitialize)PC1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PC2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)CILevel).BeginInit();
            ((System.ComponentModel.ISupportInitialize)CIHealth).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)CISpec2).BeginInit();
            SuspendLayout();
            // 
            // PC1
            // 
            PC1.Image = (Image)resources.GetObject("PC1.Image");
            PC1.Location = new Point(0, -2);
            PC1.Name = "PC1";
            PC1.Size = new Size(802, 143);
            PC1.SizeMode = PictureBoxSizeMode.StretchImage;
            PC1.TabIndex = 1;
            PC1.TabStop = false;
            // 
            // PC2
            // 
            PC2.Image = (Image)resources.GetObject("PC2.Image");
            PC2.Location = new Point(0, 130);
            PC2.Name = "PC2";
            PC2.Size = new Size(802, 871);
            PC2.SizeMode = PictureBoxSizeMode.StretchImage;
            PC2.TabIndex = 2;
            PC2.TabStop = false;
            // 
            // LBMain
            // 
            LBMain.FormattingEnabled = true;
            LBMain.ItemHeight = 15;
            LBMain.Location = new Point(801, 1);
            LBMain.Name = "LBMain";
            LBMain.Size = new Size(219, 289);
            LBMain.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(662, 64);
            label1.Name = "label1";
            label1.Size = new Size(88, 15);
            label1.TabIndex = 4;
            label1.Text = "Character Level";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(269, 64);
            label2.Name = "label2";
            label2.Size = new Size(88, 15);
            label2.TabIndex = 5;
            label2.Text = "Character Class";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(522, 98);
            label3.Name = "label3";
            label3.Size = new Size(71, 15);
            label3.TabIndex = 6;
            label3.Text = "Background";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(662, 98);
            label4.Name = "label4";
            label4.Size = new Size(74, 15);
            label4.TabIndex = 7;
            label4.Text = "Player Name";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(269, 98);
            label5.Name = "label5";
            label5.Size = new Size(32, 15);
            label5.TabIndex = 8;
            label5.Text = "Race";
            // 
            // lbl1
            // 
            lbl1.AutoSize = true;
            lbl1.Location = new Point(388, 64);
            lbl1.Name = "lbl1";
            lbl1.Size = new Size(63, 15);
            lbl1.TabIndex = 10;
            lbl1.Text = "Specialty 1";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(269, 159);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 13;
            // 
            // CISpec1
            // 
            CISpec1.Location = new Point(388, 40);
            CISpec1.Name = "CISpec1";
            CISpec1.Size = new Size(112, 23);
            CISpec1.TabIndex = 14;
            // 
            // WpnName2
            // 
            WpnName2.Location = new Point(564, 593);
            WpnName2.Name = "WpnName2";
            WpnName2.Size = new Size(108, 23);
            WpnName2.TabIndex = 15;
            // 
            // CIPlayerName
            // 
            CIPlayerName.Location = new Point(662, 78);
            CIPlayerName.Name = "CIPlayerName";
            CIPlayerName.Size = new Size(88, 23);
            CIPlayerName.TabIndex = 16;
            // 
            // WpnName1
            // 
            WpnName1.Location = new Point(564, 472);
            WpnName1.Name = "WpnName1";
            WpnName1.Size = new Size(108, 23);
            WpnName1.TabIndex = 17;
            // 
            // WpnName3
            // 
            WpnName3.Location = new Point(564, 715);
            WpnName3.Name = "WpnName3";
            WpnName3.Size = new Size(108, 23);
            WpnName3.TabIndex = 19;
            // 
            // CILevel
            // 
            CILevel.Location = new Point(662, 39);
            CILevel.Name = "CILevel";
            CILevel.Size = new Size(88, 23);
            CILevel.TabIndex = 20;
            // 
            // CIHealth
            // 
            CIHealth.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CIHealth.Location = new Point(133, 215);
            CIHealth.Name = "CIHealth";
            CIHealth.Size = new Size(73, 43);
            CIHealth.TabIndex = 21;
            CIHealth.TextAlign = HorizontalAlignment.Center;
            // 
            // numericUpDown3
            // 
            numericUpDown3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            numericUpDown3.Location = new Point(90, 418);
            numericUpDown3.Maximum = new decimal(new int[] { 20, 0, 0, 0 });
            numericUpDown3.Minimum = new decimal(new int[] { 8, 0, 0, 0 });
            numericUpDown3.Name = "numericUpDown3";
            numericUpDown3.Size = new Size(38, 29);
            numericUpDown3.TabIndex = 22;
            numericUpDown3.Value = new decimal(new int[] { 8, 0, 0, 0 });
            // 
            // numericUpDown4
            // 
            numericUpDown4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            numericUpDown4.Location = new Point(90, 519);
            numericUpDown4.Maximum = new decimal(new int[] { 20, 0, 0, 0 });
            numericUpDown4.Minimum = new decimal(new int[] { 8, 0, 0, 0 });
            numericUpDown4.Name = "numericUpDown4";
            numericUpDown4.Size = new Size(38, 29);
            numericUpDown4.TabIndex = 23;
            numericUpDown4.Value = new decimal(new int[] { 8, 0, 0, 0 });
            // 
            // numericUpDown5
            // 
            numericUpDown5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            numericUpDown5.Location = new Point(89, 622);
            numericUpDown5.Maximum = new decimal(new int[] { 20, 0, 0, 0 });
            numericUpDown5.Minimum = new decimal(new int[] { 8, 0, 0, 0 });
            numericUpDown5.Name = "numericUpDown5";
            numericUpDown5.Size = new Size(38, 29);
            numericUpDown5.TabIndex = 24;
            numericUpDown5.Value = new decimal(new int[] { 8, 0, 0, 0 });
            // 
            // numericUpDown6
            // 
            numericUpDown6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            numericUpDown6.Location = new Point(90, 724);
            numericUpDown6.Maximum = new decimal(new int[] { 20, 0, 0, 0 });
            numericUpDown6.Minimum = new decimal(new int[] { 8, 0, 0, 0 });
            numericUpDown6.Name = "numericUpDown6";
            numericUpDown6.Size = new Size(39, 29);
            numericUpDown6.TabIndex = 25;
            numericUpDown6.Value = new decimal(new int[] { 8, 0, 0, 0 });
            // 
            // numericUpDown7
            // 
            numericUpDown7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            numericUpDown7.Location = new Point(89, 825);
            numericUpDown7.Maximum = new decimal(new int[] { 20, 0, 0, 0 });
            numericUpDown7.Minimum = new decimal(new int[] { 8, 0, 0, 0 });
            numericUpDown7.Name = "numericUpDown7";
            numericUpDown7.Size = new Size(38, 29);
            numericUpDown7.TabIndex = 26;
            numericUpDown7.Value = new decimal(new int[] { 8, 0, 0, 0 });
            // 
            // numericUpDown8
            // 
            numericUpDown8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            numericUpDown8.Location = new Point(89, 927);
            numericUpDown8.Maximum = new decimal(new int[] { 20, 0, 0, 0 });
            numericUpDown8.Minimum = new decimal(new int[] { 8, 0, 0, 0 });
            numericUpDown8.Name = "numericUpDown8";
            numericUpDown8.Size = new Size(39, 29);
            numericUpDown8.TabIndex = 27;
            numericUpDown8.Value = new decimal(new int[] { 8, 0, 0, 0 });
            // 
            // CIName
            // 
            CIName.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CIName.Location = new Point(50, 83);
            CIName.Name = "CIName";
            CIName.Size = new Size(196, 35);
            CIName.TabIndex = 28;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(166, 122);
            label9.Name = "label9";
            label9.Size = new Size(93, 15);
            label9.TabIndex = 29;
            label9.Text = "Character Name";
            // 
            // CISpec
            // 
            CISpec.FormattingEnabled = true;
            CISpec.Items.AddRange(new object[] { "Warrior", "Mage" });
            CISpec.Location = new Point(269, 39);
            CISpec.Name = "CISpec";
            CISpec.Size = new Size(100, 23);
            CISpec.TabIndex = 30;
            CISpec.SelectedIndexChanged += CISpec_SelectedIndexChanged_1;
            // 
            // btnCreate
            // 
            btnCreate.Location = new Point(842, 296);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(135, 23);
            btnCreate.TabIndex = 31;
            btnCreate.Text = "Create Character";
            btnCreate.UseVisualStyleBackColor = true;
            btnCreate.Click += btnCreate_Click_1;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(388, 98);
            label10.Name = "label10";
            label10.Size = new Size(63, 15);
            label10.TabIndex = 32;
            label10.Text = "Alignment";
            // 
            // CIRace
            // 
            CIRace.FormattingEnabled = true;
            CIRace.Items.AddRange(new object[] { "Human", "Elf", "Half-Elf", "Dwarf", "Halfling", "Gnome", "Orc", "Tiefling", "Goliath", "", "" });
            CIRace.Location = new Point(269, 78);
            CIRace.Name = "CIRace";
            CIRace.Size = new Size(100, 23);
            CIRace.TabIndex = 34;
            // 
            // CIAlignment
            // 
            CIAlignment.FormattingEnabled = true;
            CIAlignment.Items.AddRange(new object[] { "Lawful Good", "Lawful Neutral", "Lawful Evil", "Neutral Good", "True Neutral", "Neutral Evil", "Chaotic Good", "Chaotic Neutral", "Chaotic Evil" });
            CIAlignment.Location = new Point(388, 78);
            CIAlignment.Name = "CIAlignment";
            CIAlignment.Size = new Size(112, 23);
            CIAlignment.TabIndex = 35;
            // 
            // CIBackground
            // 
            CIBackground.FormattingEnabled = true;
            CIBackground.Items.AddRange(new object[] { "Acolyte", "Charlatan", "Criminal", "Entertainer", "Folk Hero", "Guild Artisan", "Noble", "Outlander", "Sage", "Soldier", "Urchin" });
            CIBackground.Location = new Point(522, 78);
            CIBackground.Name = "CIBackground";
            CIBackground.Size = new Size(106, 23);
            CIBackground.TabIndex = 36;
            // 
            // SCCastAbility
            // 
            SCCastAbility.FormattingEnabled = true;
            SCCastAbility.Location = new Point(350, 525);
            SCCastAbility.Name = "SCCastAbility";
            SCCastAbility.Size = new Size(53, 23);
            SCCastAbility.TabIndex = 39;
            // 
            // lbl2
            // 
            lbl2.AutoSize = true;
            lbl2.Location = new Point(522, 64);
            lbl2.Name = "lbl2";
            lbl2.Size = new Size(63, 15);
            lbl2.TabIndex = 41;
            lbl2.Text = "Specialty 2";
            // 
            // checkedListBox1
            // 
            checkedListBox1.FormattingEnabled = true;
            checkedListBox1.Location = new Point(1020, 511);
            checkedListBox1.Name = "checkedListBox1";
            checkedListBox1.Size = new Size(120, 94);
            checkedListBox1.TabIndex = 42;
            // 
            // CISpec2
            // 
            CISpec2.Location = new Point(522, 40);
            CISpec2.Name = "CISpec2";
            CISpec2.Size = new Size(106, 23);
            CISpec2.TabIndex = 44;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(336, 354);
            label12.Name = "label12";
            label12.Size = new Size(47, 37);
            label12.TabIndex = 43;
            label12.Text = "10";
            // 
            // Mainfrm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1020, 1000);
            Controls.Add(CISpec2);
            Controls.Add(label12);
            Controls.Add(checkedListBox1);
            Controls.Add(CIBackground);
            Controls.Add(lbl2);
            Controls.Add(SCCastAbility);
            Controls.Add(CIAlignment);
            Controls.Add(CIRace);
            Controls.Add(btnCreate);
            Controls.Add(CISpec);
            Controls.Add(label9);
            Controls.Add(CIName);
            Controls.Add(numericUpDown8);
            Controls.Add(numericUpDown7);
            Controls.Add(numericUpDown6);
            Controls.Add(numericUpDown5);
            Controls.Add(numericUpDown4);
            Controls.Add(numericUpDown3);
            Controls.Add(CIHealth);
            Controls.Add(CILevel);
            Controls.Add(WpnName3);
            Controls.Add(WpnName1);
            Controls.Add(CIPlayerName);
            Controls.Add(WpnName2);
            Controls.Add(CISpec1);
            Controls.Add(textBox2);
            Controls.Add(lbl1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(LBMain);
            Controls.Add(PC2);
            Controls.Add(label10);
            Controls.Add(PC1);
            Name = "Mainfrm";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)PC1).EndInit();
            ((System.ComponentModel.ISupportInitialize)PC2).EndInit();
            ((System.ComponentModel.ISupportInitialize)CILevel).EndInit();
            ((System.ComponentModel.ISupportInitialize)CIHealth).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown4).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown5).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown6).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown7).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown8).EndInit();
            ((System.ComponentModel.ISupportInitialize)CISpec2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private PictureBox PC1;
        private PictureBox PC2;
        private ListBox LBMain;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label lbl1;
        private TextBox textBox2;
        private TextBox CISpec1;
        private TextBox WpnName2;
        private TextBox CIPlayerName;
        private TextBox WpnName1;
        private TextBox WpnName3;
        private NumericUpDown CILevel;
        private NumericUpDown CIHealth;
        private NumericUpDown numericUpDown3;
        private NumericUpDown numericUpDown4;
        private NumericUpDown numericUpDown5;
        private NumericUpDown numericUpDown6;
        private NumericUpDown numericUpDown7;
        private NumericUpDown numericUpDown8;
        private TextBox CIName;
        private Label label9;
        private ComboBox CISpec;
        private Button btnCreate;
        private Label label10;
        private ComboBox CIRace;
        private ComboBox CIAlignment;
        private ComboBox CIBackground;
        private ComboBox SCCastAbility;
        private Label lbl2;
        private CheckedListBox checkedListBox1;
        private NumericUpDown CISpec2;
        private Label label12;
    }
}
